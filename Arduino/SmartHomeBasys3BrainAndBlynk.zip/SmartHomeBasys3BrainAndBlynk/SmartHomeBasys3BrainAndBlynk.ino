#define BLYNK_TEMPLATE_ID "TMPL6RulmMvRU"
#define BLYNK_TEMPLATE_NAME "smart homie"
#define BLYNK_AUTH_TOKEN    "-0f1CwpgWURL5wRK6J6uh25fqc53wT1V"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <ESP32Servo.h>
#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define PIR_PIN       14
#define LED_PIN        2
#define BUZZER_PIN    33
#define RELAY_PIN     27
#define SERVO_PIN     25

#define DHT_PIN       32
#define DHT_TYPE      DHT22

#define TRIG_PIN      26
#define ECHO_PIN      34

#define BASYS_RX_PIN  16
#define BASYS_TX_PIN  17
#define BASYS_BAUD    9600

char ssid[] = "internet";
char pass[] = "123456789";

LiquidCrystal_I2C lcd(0x27, 20, 4);
Servo myServo;
DHT dht(DHT_PIN, DHT_TYPE);
BlynkTimer timer;

// ===== timing =====
unsigned long lastDhtReadTime = 0;
const unsigned long dhtInterval = 2000;

unsigned long lastUltrasonicReadTime = 0;
const unsigned long ultrasonicInterval = 300;

unsigned long lastLcdUpdateTime = 0;
const unsigned long lcdUpdateInterval = 500;

unsigned long lastSerialPrintTime = 0;
const unsigned long serialPrintInterval = 1000;

unsigned long lastReconnectAttempt = 0;
const unsigned long reconnectInterval = 10000;

// ===== sensor values =====
float temperature = 0.0;
float humidity = 0.0;
float distanceCm = 999.0;

// ===== PIR filter =====
bool pirWarmupDone = false;
unsigned long pirWarmupStart = 0;
const unsigned long pirWarmupTime = 60000;   // 60 sec

bool motionRaw = false;
bool motionStable = false;
bool lastSentMotionStable = true;

int pirHighCount = 0;
int pirLowCount = 0;
const int pirThreshold = 5;   // loop ~20ms => ~100ms filter

bool nearRaw = false;
bool lastSentNearRaw = true;

// ===== outputs =====
bool ledState = false;
bool relayState = false;
int servoAngle = 0;

// ===== buzzer non-block =====
bool buzzerActive = false;
unsigned long buzzerStartTime = 0;
unsigned long buzzerDuration = 0;

// PIR -> buzzer cooldown
bool lastMotionStableForBuzzer = false;
unsigned long lastPirBuzzerTime = 0;
const unsigned long pirBuzzerCooldown = 1500;

// ===== function declarations =====
void startBuzzer(unsigned long durationMs);
void updateBuzzer();
void updatePirFilter();
void sendSensorStatesToBasys();
void executeCommand(char cmd);
void readCommandsFromBasys();
void readDHTSensor();
float readUltrasonic();
void handlePirTriggeredBuzzer();
void updateLCD();
void printStatus();
void sendToBlynk();
void connectWiFiAndBlynk();
void checkConnection();
void applyLed(bool state);
void applyRelay(bool state);
void applyServo(int angle);

// ===== helper functions =====
void applyLed(bool state) {
  ledState = state;
  digitalWrite(LED_PIN, ledState ? HIGH : LOW);
}

void applyRelay(bool state) {
  relayState = state;
  // active LOW relay
  digitalWrite(RELAY_PIN, relayState ? LOW : HIGH);
}

void applyServo(int angle) {
  if (angle < 0) angle = 0;
  if (angle > 180) angle = 180;
  servoAngle = angle;
  myServo.write(servoAngle);
}

void startBuzzer(unsigned long durationMs) {
  buzzerActive = true;
  buzzerStartTime = millis();
  buzzerDuration = durationMs;
  digitalWrite(BUZZER_PIN, HIGH);
}

void updateBuzzer() {
  if (buzzerActive && millis() - buzzerStartTime >= buzzerDuration) {
    buzzerActive = false;
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void updatePirFilter() {
  motionRaw = (digitalRead(PIR_PIN) == HIGH);

  if (motionRaw) {
    pirHighCount++;
    pirLowCount = 0;

    if (pirHighCount >= pirThreshold) {
      motionStable = true;
      pirHighCount = pirThreshold;
    }
  } else {
    pirLowCount++;
    pirHighCount = 0;

    if (pirLowCount >= pirThreshold) {
      motionStable = false;
      pirLowCount = pirThreshold;
    }
  }
}

void sendSensorStatesToBasys() {
  if (motionStable != lastSentMotionStable) {
    Serial2.write(motionStable ? 'M' : 'm');
    Serial.print("[TX Basys] MotionStable -> ");
    Serial.println(motionStable ? "M" : "m");
    lastSentMotionStable = motionStable;
  }

  if (nearRaw != lastSentNearRaw) {
    Serial2.write(nearRaw ? 'N' : 'n');
    Serial.print("[TX Basys] Near -> ");
    Serial.println(nearRaw ? "N" : "n");
    lastSentNearRaw = nearRaw;
  }
}

void executeCommand(char cmd) {
  Serial.print("[RX Basys] cmd = ");
  Serial.println(cmd);

  switch (cmd) {
    case 'L':
      applyLed(true);
      break;

    case 'l':
      applyLed(false);
      break;

    case 'R':
      applyRelay(true);
      break;

    case 'r':
      applyRelay(false);
      break;

    case 'S':
      applyServo(90);
      break;

    case 's':
      applyServo(0);
      break;

    case 'B':
      startBuzzer(150);
      break;
  }
}

void readCommandsFromBasys() {
  while (Serial2.available() > 0) {
    char cmd = (char)Serial2.read();
    executeCommand(cmd);
  }
}

void readDHTSensor() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (!isnan(h) && !isnan(t)) {
    humidity = h;
    temperature = t;
  }
}

float readUltrasonic() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) {
    return 999.0;
  }

  return duration * 0.0343 / 2.0;
}

void handlePirTriggeredBuzzer() {
  if (motionStable && !lastMotionStableForBuzzer) {
    if (millis() - lastPirBuzzerTime >= pirBuzzerCooldown) {
      Serial.println("[BUZZER] Motion detected -> Beep");
      startBuzzer(200);
      lastPirBuzzerTime = millis();
    }
  }

  lastMotionStableForBuzzer = motionStable;
}

void updateLCD() {
  if (millis() - lastLcdUpdateTime < lcdUpdateInterval) return;
  lastLcdUpdateTime = millis();

  char line[21];

  if (!pirWarmupDone) {
    unsigned long remain = (pirWarmupTime - (millis() - pirWarmupStart)) / 1000;
    if ((long)remain < 0) remain = 0;

    lcd.setCursor(0, 0);
    lcd.print("PIR Warm-up        ");
    snprintf(line, sizeof(line), "Remain:%2lus       ", remain);
    lcd.setCursor(0, 1);
    lcd.print(line);

    snprintf(line, sizeof(line), "WiFi:%-3s B:%-3s    ",
             (WiFi.status() == WL_CONNECTED) ? "ON" : "OFF",
             Blynk.connected() ? "ON" : "OFF");
    lcd.setCursor(0, 2);
    lcd.print(line);

    lcd.setCursor(0, 3);
    lcd.print("Please wait...     ");
    return;
  }

  snprintf(line, sizeof(line), "PIR:%-3s Raw:%-3s    ",
           motionStable ? "ON" : "OFF",
           motionRaw ? "ON" : "OFF");
  lcd.setCursor(0, 0);
  lcd.print(line);

  if (distanceCm >= 999.0) {
    snprintf(line, sizeof(line), "Dist:NoObj Servo:%3d", servoAngle);
  } else {
    snprintf(line, sizeof(line), "Dist:%5.1fcm S:%3d ", distanceCm, servoAngle);
  }
  lcd.setCursor(0, 1);
  lcd.print(line);

  snprintf(line, sizeof(line), "Temp:%4.1fC Hum:%4.1f", temperature, humidity);
  lcd.setCursor(0, 2);
  lcd.print(line);

  snprintf(line, sizeof(line), "LED:%-3s Fan:%-3s B:%-3s",
           ledState ? "ON" : "OFF",
           relayState ? "ON" : "OFF",
           Blynk.connected() ? "ON" : "OFF");
  lcd.setCursor(0, 3);
  lcd.print(line);
}

void printStatus() {
  Serial.print("WiFi:");
  Serial.print((WiFi.status() == WL_CONNECTED) ? "OK" : "FAIL");

  Serial.print(" | Blynk:");
  Serial.print(Blynk.connected() ? "OK" : "OFF");

  Serial.print(" | PIRready:");
  Serial.print(pirWarmupDone ? "YES" : "NO");

  Serial.print(" | Raw:");
  Serial.print(motionRaw ? "1" : "0");

  Serial.print(" | Stable:");
  Serial.print(motionStable ? "1" : "0");

  Serial.print(" | Near:");
  Serial.print(nearRaw ? "1" : "0");

  Serial.print(" | Dist:");
  Serial.print(distanceCm);
  Serial.print("cm");

  Serial.print(" | Temp:");
  Serial.print(temperature);

  Serial.print(" | Hum:");
  Serial.print(humidity);

  Serial.print(" | LED:");
  Serial.print(ledState ? "ON" : "OFF");

  Serial.print(" | Relay:");
  Serial.print(relayState ? "ON" : "OFF");

  Serial.print(" | Servo:");
  Serial.print(servoAngle);

  Serial.print(" | Buzzer:");
  Serial.println(buzzerActive ? "ON" : "OFF");
}

void sendToBlynk() {
  if (!Blynk.connected()) return;

  Blynk.virtualWrite(V0, temperature);
  Blynk.virtualWrite(V1, humidity);
  Blynk.virtualWrite(V6, motionStable ? 1 : 0);
  Blynk.virtualWrite(V7, distanceCm >= 999.0 ? 0 : distanceCm);

  Serial.print("[Blynk] T=");
  Serial.print(temperature);
  Serial.print(" H=");
  Serial.print(humidity);
  Serial.print(" PIR=");
  Serial.print(motionStable ? 1 : 0);
  Serial.print(" D=");
  Serial.println(distanceCm);
}

void connectWiFiAndBlynk() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);

  Serial.print("Connecting WiFi");
  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 15000) {
    Serial.print(".");
    delay(250);
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi connected. IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("WiFi connect timeout");
  }

  Blynk.config(BLYNK_AUTH_TOKEN);

  if (WiFi.status() == WL_CONNECTED) {
    if (Blynk.connect(10000)) {
      Serial.println("Blynk connected");
    } else {
      Serial.println("Blynk connect timeout");
    }
  }
}

void checkConnection() {
  if (millis() - lastReconnectAttempt < reconnectInterval) return;
  lastReconnectAttempt = millis();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[Reconnect] WiFi lost, reconnecting...");
    WiFi.disconnect();
    WiFi.begin(ssid, pass);
    return;
  }

  if (!Blynk.connected()) {
    Serial.println("[Reconnect] Blynk lost, reconnecting...");
    Blynk.connect(5000);
  }
}

// ===== Blynk handlers =====
BLYNK_CONNECTED() {
  Serial.println("[Blynk] Connected to cloud");
  Blynk.syncVirtual(V2, V3, V4);
}

BLYNK_WRITE(V2) {
  int value = param.asInt();
  applyLed(value == 1);
}

BLYNK_WRITE(V3) {
  int value = param.asInt();
  applyRelay(value == 1);
}

BLYNK_WRITE(V4) {
  int value = param.asInt();
  applyServo(value);
}

BLYNK_WRITE(V5) {
  int value = param.asInt();
  if (value == 1) {
    startBuzzer(200);
  }
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(BASYS_BAUD, SERIAL_8N1, BASYS_RX_PIN, BASYS_TX_PIN);

  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RELAY_PIN, HIGH);
  digitalWrite(TRIG_PIN, LOW);

  myServo.attach(SERVO_PIN);
  applyServo(0);

  dht.begin();

  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("System booting...  ");

  pirWarmupStart = millis();

  connectWiFiAndBlynk();

  timer.setInterval(2000L, sendToBlynk);

  motionRaw = false;
  motionStable = false;
  nearRaw = false;
  lastSentMotionStable = true;
  lastSentNearRaw = true;
  lastMotionStableForBuzzer = false;
  lastPirBuzzerTime = 0;

  startBuzzer(100);
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    Blynk.run();
  }
  timer.run();

  updateBuzzer();
  checkConnection();

  if (!pirWarmupDone) {
    if (millis() - pirWarmupStart >= pirWarmupTime) {
      pirWarmupDone = true;
      Serial.println("PIR warm-up complete");
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("System Ready       ");
      startBuzzer(150);
    }

    updateLCD();

    if (millis() - lastSerialPrintTime >= serialPrintInterval) {
      lastSerialPrintTime = millis();
      printStatus();
    }

    delay(20);
    return;
  }

  updatePirFilter();

  unsigned long currentTime = millis();

  if (currentTime - lastDhtReadTime >= dhtInterval) {
    lastDhtReadTime = currentTime;
    readDHTSensor();
  }

  if (currentTime - lastUltrasonicReadTime >= ultrasonicInterval) {
    lastUltrasonicReadTime = currentTime;
    distanceCm = readUltrasonic();
    nearRaw = (distanceCm < 10.0);
  }

  handlePirTriggeredBuzzer();
  sendSensorStatesToBasys();
  readCommandsFromBasys();
  updateLCD();

  if (currentTime - lastSerialPrintTime >= serialPrintInterval) {
    lastSerialPrintTime = currentTime;
    printStatus();
  }

  delay(20);
}